# Version 0.0.5 02-27-2019

  * fixed issues with render_one and timestamp

# Version 0.0.4 12-13-2018 

  * removed xlsx support and dependencies
  
# Version 0.0.3 10-30-2018 

  * added tab_files()
  * cleaned up some documentation issues
  
# Version 0.0.2 01-08-2018 

  * edited load_prj
  * removed some doc examples which do not work
  * edited xlsx functions (plan to remove and replace with openxlsx)
  
# Version 0.0.2 01-08-2018 

  * Formal package set-up according to devtools
  * Built gitpages site
  * renamed functions to streamline  
  
# Version 0.0.1

Project set-up, data upload.



